#include <iostream>
#include<cmath>
#include<stdio.h>
#include<vector>
#include "University_Kovaletz.h"
using namespace std;
class Persone;
class Recordbook;
class Student;
class Profession;
class Worker;
class Teacher;
//�������-����� ����� ��������
void Recordbook::output()
{
    for(int i=0;i<marks.size();i++)
    {
       cout<<disciplines[i]<<" "<<marks[i]<<endl;
    }
}
void Recordbook::input()
{
    cout<<"Enter number of disciplines"<<endl;
    int n;
    cin>>n;
    size=n;
    disciplines.resize(n);
    marks.resize(n);
    vector<int>y(n);
    for(int i=0; i<n; i++)
    {
        cout<<"Enter name of discipline"<<endl;
        getchar();
        cin>>disciplines[i];
        cout<<"Enter mark in recordbook"<<endl;
        cin>>marks[i];
    }
}
double Recordbook:: middle_mark()
{
    double sum=0;
    for(int i=0; i<size; i++)
    {
        sum+=marks[i];
    }
    cout<<size;
    return sum/size;
}

//�������-����� ����� �������
double Student::get_bursary()
{
    return base*coefficient+base;
}
void Student::output()
{
    cout<<"Name "<<name<<endl<<"Base bursary "<<base<<endl<<"Middle mark "<<book.middle_mark()<<endl<<"Bursary "<<get_bursary()<<endl;
    cout<<"Recordbook "<<endl;
    book.output();
}
void Student::input()
{
    cout<<"Enter name, base bursary"<<endl;
    cin>>name;
    cin>>base;
    cout<<"Enter data in recordbook"<<endl;
    book.input();
    coefficient=book.middle_mark()/100;
}
//������ ����� �������
void Profession::output()
{
    cout<<"Profession: "<<name<<" Base wage: "<<base_wage;
}
void Profession::input()
{
    cout<<"Enter Profession and base wage "<<endl;
    cin>>name;
    cin>>base_wage;
}
//������ ����� ���������

double Worker::get_wage()
{
    return Prof.base_wage+(seniority*coefficient1+degree*coefficient2)*Prof.base_wage;
}
void Worker::output()
{
    cout<<"Surname: "<<surname<<" Seniority: "<<seniority<<" Degree: "<<degree<<endl;
    Prof.output();
    cout<<"Factors of the seniority, dergee: "<<coefficient1<<" "<<coefficient2<<endl;
    cout<<"Wage"<<endl;
    cout<<get_wage()<<endl;
}
void Worker::input()
{
    cout<<"Enter surname, seniority, degree:"<<endl;
    cin>>surname;
    cin>>seniority;
    cin>>degree;
    Prof.input();
    cout<<"Enter factors of the seniority, degree:"<<endl;
    cin>>coefficient1;
    cin>>coefficient2;
}
//������ ����� ��������
void Teacher::add(Student s)
{
    MyStudent s1(s.name,s.base, s.book);
        count1+=s1.book.middle_mark()*s1.book.size;
        count2+=s1.book.size;

};
void Teacher::add(int number)
{
    for(int i=0; i < number;i++)
    {
        MyStudent s1;
        s1.input();
        count1+=s1.book.middle_mark()*s1.book.size;
        count2+=s1.book.size;
    }
}
double Teacher::middlemark()
{
    if(count2==0)
        return 0;
    return count1/count2;
}
