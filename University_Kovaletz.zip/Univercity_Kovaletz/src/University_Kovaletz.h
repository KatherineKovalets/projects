#ifndef UNIVERSITY_KOVALETZ_H_INCLUDED
#define UNIVERSITY_KOVALETZ_H_INCLUDED
#include <iostream>
#include<cmath>
#include<vector>
#include<vector>
#include<vector>
using namespace std;
class Persone
{
public:
    Persone(){};
    ~Persone(){};
};
class Recordbook
    {

    public:
        int size;
            Recordbook(){};
        Recordbook(vector<string> x,vector<int>y)
        {
        size=x.size();
        if(disciplines.size()==0)
        {
            disciplines.resize(x.size());
            marks.resize(y.size());
        }
        for(int i=0; i<x.size(); i++)
        {
            disciplines[i]=x[i];
            marks[i]=y[i];
        }
        };
        ~Recordbook()
        {
            disciplines.clear();
            marks.clear();
        };
            double middle_mark();
            void output();
            void input();
        private:
            vector<string> disciplines;
            vector<int> marks;
            friend class Student;
        };
class Student:public Persone
{
protected:

    double coefficient;
    int base;
    string name;
public:
    Student(){};
    Student(string x, int y, Recordbook b):name(x), coefficient(b.middle_mark()),base(y),book(b)
    {
        name=x;
        base=y;
        book=b;
        coefficient=b.middle_mark()/100;
    };
    friend class Recordbook;
    friend class Teacher;
    Recordbook book;
    double get_bursary();//��������
    void output();
    void input();
};
class Profession
    {
        string name;
        int base_wage;
        friend class Worker;
        friend class Teacher;
    public:
        Profession(){};
        Profession(string x, int y):name(x),base_wage(y)
        {
            name=x;
            base_wage=y;
        };
        ~Profession(){};
        void output();
        void input();
        };
class Worker: public Persone
{
    Profession Prof;
    int seniority;
    int degree;
    int base;
    string surname;
private:
    double coefficient1;
    double coefficient2;
public:
   friend class Profession;

    Worker(){};
    Worker(string n, int x, int y, double a, double b, Profession p):surname(n), seniority(x), degree(y), coefficient1(a),
    coefficient2(b),Prof(p)
    {
        surname=n;
        seniority=x;
        degree=y;
        coefficient1=a;
        coefficient2=b;
        Prof=p;
    };
    double get_wage();
    void output();
    void input();
    ~Worker(){};
};
class Teacher: public Worker
{
    class MyStudent: public Student
    {
    public:
    MyStudent(){};
    MyStudent(string x, int y, Recordbook b):Student(x, y, b)
    {
    };
    ~MyStudent(){};
    } ;
   public:
         double count1;
         double count2;
    Teacher(){};
    Teacher(string n, int x, int y, double a, double b, Profession p):Worker(n, x, y, a, b, p)
    {count1=0;
    count2=0;};
    ~Teacher(){};
    void add(Student s);
    void add(int number);
    double middlemark();
       friend class Profession;
       friend class Student;
};
#endif // UNIVERSITY_KOVALETZ_H_INCLUDED
