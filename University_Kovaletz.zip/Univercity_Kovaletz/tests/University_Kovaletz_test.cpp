#include <iostream>
#include<cmath>
#include<vector>
#include "../src/University_Kovaletz.h"
int main()
{
    string arr[]={"Matan", "Diffgeom", "Program"};
    string arr1[]={"Matan", "Diffgeom", "Program","Mechanics"};
    string arr2[]={"Matan", "DiffRivn", "Program"};
    string arr3[]={"Philosophy", "BusinessGames","UZK"};
    vector<string> x(arr,arr+3),x1(arr1,arr1+4),x2(arr2,arr2+3),x3(arr3,arr3+3);
    int arr0[]={100,90,85};
    int arr01[]={90,90,90,90};
    int arr02[]={61,80,65};
    int arr03[]={99,75,80};
    vector<int> y(arr0,arr0+3), y1(arr01,arr01+4), y2(arr02,arr02+3), y3(arr03,arr03+3);
    Recordbook BookArthem(x, y);
    Recordbook BookKate(x1, y1);
    Recordbook BookEvgeniy(x2, y2);
    Recordbook BookIliya(x3, y3);
    Student Arthem("Arthem", 1200,BookArthem);
    Student Kate("Kate", 1200,BookKate);
    Student Evgeniy("Evgeniy", 1200,BookEvgeniy);
    Student Iliya("Iliya", 1200,BookIliya);
    Profession Teacher1("Teacher",10000);
    Teacher Petrova("Petrova",20,3,0.07,0.02,Teacher1);
    Teacher Zrazhevsky("Zrazhevsky",30,3,0.07,0.02,Teacher1);
    Petrova.add(Arthem);
    Petrova.add(Iliya);
    Petrova.add(Evgeniy);
    Zrazhevsky.add(Kate);
    cout<<"Petrova's students' middle mark: "<<Petrova.middlemark()<<endl;
    cout<<"Expected result: 81.666"<<endl;
    cout<<"Zrazhevsky's students' middle mark: "<<Zrazhevsky.middlemark()<<endl;
    cout<<"Expected result: 90"<<endl;

    Petrova.output();
    cout<<endl<<"Expected results:"<<endl<<"Surname: "<<"Petrova"<<" Seniority: "<<20<<" Degree: "<<3<<endl;
    cout<<"Profession: "<<"Teacher"<<" Base wage: "<<10000;
    cout<<"Factors of the seniority, dergee: "<<0.07<<" "<<0.02<<endl;
    cout<<"Wage"<<endl;
    cout<<10000+(0.02*3+0.07*20)*10000<<endl;
     Arthem.output();
     cout<<endl<<"Expected results:"<<endl;
    cout<<"Name "<<"Arthem"<<endl<<"Base bursary "<<1200<<endl<<"Middle mark "<<91.666<<endl<<"Bursary "<<1200*91.666/100+1200<<endl;
    cout<<"Recordbook "<<endl;
    for(int i=0;i<x.size();i++)
    {
       cout<<x[i]<<" "<<y[i]<<endl;
    }
    Student A;
    Teacher B;
    A.input();
    A.output();
    B.input();
    B.output();

    return 0;
}
